﻿using Microsoft.AspNetCore.Mvc;

namespace Inventario_P.Controllers
{
    public class MovimientoPController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
