﻿using Microsoft.Data.SqlClient;
using Inventario_P.Models;
using System;
using System.Collections.Generic;
using Inventario_P.Context;
using System.Linq;

namespace Inventario_P.Models
{
    public class BitacoraBD
    {
        // Context genérico con constructor vacío o por defecto
        Inventario_P.Context.Context con = new Inventario_P.Context.Context();

        public List<Bitacora> ObtenerBitacoras()
        {
            List<Bitacora> usersBaseDeDatos = new List<Bitacora>();
            string query = "SELECT   b.ID_login,   u.Usuario AS NombreUsuario,   b.Fecha,   b.Accion FROM Bitacora b left JOIN Usuarios u ON b.ID_usuario = u.ID_Usuario ORDER BY b.Fecha DESC;";

            // Abrimos la conexión usando la clase Context
            using (SqlConnection connection = con.OpenConnection())
            using (SqlCommand command = new SqlCommand(query, connection))
            using (SqlDataReader reader = command.ExecuteReader())
            {
                var result = reader;
                while (reader.Read())
                {
                    int ID_login = reader.GetInt32(0);
                    string NombreUsuario = reader.IsDBNull(1) ? string.Empty : reader.GetString(1);
                    DateTime FechaHora = reader.GetDateTime(2);
                    string Accion = reader.IsDBNull(3) ? string.Empty : reader.GetString(3);




                    // Agregamos cada fila a la lista
                    usersBaseDeDatos.Add(new Bitacora
                    {
                        IdLogin = ID_login,
                        NombreUsuario = NombreUsuario,
                        Fecha = FechaHora, 
                        Accion = Accion
                       
                    });
                }
            }

            return usersBaseDeDatos;
        }
    }
}
