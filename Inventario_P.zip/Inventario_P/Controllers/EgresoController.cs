﻿using Microsoft.AspNetCore.Mvc;

namespace Inventario_P.Controllers
{
    public class EgresoController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
