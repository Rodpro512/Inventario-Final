using Inventario_P.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using System.Data;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Text;

namespace Inventario_P.Controllers
{
    public class HomeController : Controller
    {
        [HttpGet]
        public IActionResult Index()
        {
            return View(new VistaConTablasViewModel());
        }

        [HttpPost]
        public IActionResult Index(VistaConTablasViewModel model)
        {
            // Carga los datos seg�n la tabla seleccionada
            switch (model.tablaSeleccionada)
            {
                case "Producto":
                    model.ProductoData = new ProductoDB().ObtenerProductos();
                    break;

                case "Bitacora":
                    model.BitacoraData = new BitacoraBD().ObtenerBitacoras();
                    break;

                case "MovimientoDeProducto":
                    model.MovimientoDeProductoData = new MovimientoDeProductoDB().ObtenerMovimientos();
                    break;
            }

            return View(model);
        }
        static string cadena = "Data Source=PROYECTO11\\SQL_RODRIGO;Initial Catalog=InventarioSQL;Integrated Security=True; TrustServerCertificate=True";

        [HttpPost]
        public IActionResult Login(DataUser oUsuarios)
        {
            Usuarios dbUsuario = new Usuarios();
            dbUsuario.Contrase�a = ConvertirClave(oUsuarios.Contrase�a);
            using (SqlConnection conn = new SqlConnection(cadena))
            {
                SqlCommand cmd = new SqlCommand("SP_ValidarUsuarios", conn);
                cmd.Parameters.AddWithValue("Usuario", oUsuarios.Usuario);
                cmd.Parameters.AddWithValue("Contrase�a", dbUsuario.Contrase�a);
                cmd.CommandType = CommandType.StoredProcedure;

                conn.Open();
                dbUsuario.Usuario = (string)cmd.ExecuteScalar();
            }

            if (dbUsuario.Usuario != null)
            {
                //Session["Usuario"] = oUsuarios; 
                return RedirectToAction("Index", "Informativo");

            }
            else
            {
                ViewData["Mensaje"] = "Usuario no encontrado";
                return View("Index", "Home");
            }
        }

        public static byte[] ConvertirClave(string texto)
        {
            StringBuilder sb = new StringBuilder();
            byte[] result;
            using (SHA256 hash = SHA256.Create())
            {
                Encoding enc = Encoding.UTF8;
                result = hash.ComputeHash(enc.GetBytes(texto));

                //foreach (byte b in result)
                //sb.Append(b.ToString("x2"));
            }

            //return sb.ToString();
            return result;

        }
        public class DataUser
        {
            public string Usuario { get; set; }
            public string Contrase�a { get; set; }
        }
    }
}
