﻿using Inventario_P.Models;
using Microsoft.AspNetCore.Mvc;

namespace Inventario_P.Controllers
{
    public class MovimientoPController : Controller
    {
        private ProductoDB productoDB = new ProductoDB();
        public IActionResult Index()
        {
            ViewBag.Producto = productoDB.ObtenerProductos();
            return View();
        }

        [HttpPost]
        public IActionResult RegistrarMovimiento(int idProducto, int cantidad, DateTime fecha, string tipo)
        {
            int idUsuario = 1; // Aquí lo ideal es obtener el usuario logueado desde sesión

            MovimientoDeProductoDB db = new MovimientoDeProductoDB();

            try
            {
                db.RegistrarMovimiento(idProducto, idUsuario, cantidad, fecha, tipo);
                TempData["mensaje"] = "Movimiento registrado con éxito.";
                TempData["Exito"] = true;
            }
            catch (Exception ex)
            {
                TempData["error"] = "Error: " + ex.Message;
            }

            return RedirectToAction("Index");

        }

    }
}
