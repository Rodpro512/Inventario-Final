﻿using Inventario_P.Models;
using Microsoft.AspNetCore.Mvc;

namespace Inventario_P.Controllers
{
    public class MovimientoPController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public IActionResult RegistrarMovimiento(int idProducto, int cantidad, DateTime fecha, string tipo)
        {
            int idUsuario = 1; // Aquí lo ideal es obtener el usuario logueado desde sesión

            MovimientoDeProductoDB db = new MovimientoDeProductoDB();

            try
            {
                db.RegistrarMovimiento(idProducto, idUsuario, cantidad, fecha, tipo);
                TempData["mensaje"] = "Movimiento registrado con éxito.";
            }
            catch (Exception ex)
            {
                TempData["error"] = "Error: " + ex.Message;
            }

            return RedirectToAction("Index");
        }

    }
}
