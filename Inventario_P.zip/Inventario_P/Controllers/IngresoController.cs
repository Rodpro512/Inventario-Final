﻿using Microsoft.AspNetCore.Mvc;

namespace Inventario_P.Controllers
{
    public class IngresoController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
