﻿using Inventario_P.Models;
using Microsoft.AspNetCore.Mvc;

public class CreacionController : Controller
{
    private ProductoDB productoDB = new ProductoDB(); // Instancia de la clase

    public IActionResult Index()
    {
        // El ViewBag prmite pasar datos entre un controlador y una vista durante la misma solicitud HTTP
        ViewBag.Marcas = productoDB.ObtenerMarcas();
        ViewBag.Categorium = productoDB.ObtenerCategorias();
        return View();
    }

    [HttpPost]
    public IActionResult Index(Producto producto)
    {
        Console.WriteLine("Entró al método POST"); //pRUEBA PARA VER SI ENTRA PORQUE NO FUNCIONAAAAAAAA

        if (ModelState.IsValid)
        {
            Console.WriteLine("Modelo válido"); //Prueba para ver si entra...

            ProductoDB productoDB = new ProductoDB();
            productoDB.ProductoAdd(producto);
            return RedirectToAction("Index");
        }

        Console.WriteLine("Modelo NO válido"); //NOOOOOOOOOOOOO
        
        //ME RINDO, ESTO LO SAQUE DE LA WEB PARA SABER QUE PASA
        if (!ModelState.IsValid)
        {
            foreach (var state in ModelState)
            {
                foreach (var error in state.Value.Errors)
                {
                    Console.WriteLine($"Error en {state.Key}: {error.ErrorMessage}");
                }
            }

            return View(producto);
        }

        return View(producto);
    }
}