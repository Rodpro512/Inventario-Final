﻿using Inventario_P.Context;
using Inventario_P.Models;
using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory;

namespace Inventario_P.Models
{  
    public class MovimientoDeProductoDB
    {

        // Context genérico con constructor vacío o por defecto
        Inventario_P.Context.Context con = new Inventario_P.Context.Context();


        public List<MovimientoDeProducto> ObtenerMovimientos()
        {
            List<MovimientoDeProducto> usersBaseDeDatos = new List<MovimientoDeProducto>();
            string query = "SELECT * FROM Movimiento_de_Productos";

            // Abrimos la conexión usando la clase Context
            using (SqlConnection connection = con.OpenConnection())
            using (SqlCommand command = new SqlCommand(query, connection))
            using (SqlDataReader reader = command.ExecuteReader())
            {
                while (reader.Read())
                {
                    int ID_producto = reader.GetInt32(1);
                    int ID_Moviento = reader.GetInt32(0);
                    int ID_usuario = reader.GetInt32(2);
                    int Cantidad = reader.GetInt32(3);
                    DateTime FechaHora = reader.GetDateTime(4);
                    DateOnly Fecha = DateOnly.FromDateTime(FechaHora);
                    String Tipo = reader.GetString(5);

                    // Agregamos cada fila a la lista
                    usersBaseDeDatos.Add(new MovimientoDeProducto
                    {
                        IdMoviento = ID_Moviento,
                        IdProducto = ID_producto,
                        IdUsuario = ID_usuario,
                        Cantidad = Cantidad,
                        Fecha = Fecha,
                        Tipo = Tipo
                    });
                }
            }

            return usersBaseDeDatos;
        }

        public void RegistrarMovimiento(int idProducto, int idUsuario, int cantidad, DateTime fecha, string tipo)
        {

            using (SqlConnection cn = con.OpenConnection())
            {


                SqlCommand cmd = new SqlCommand("SP_MovimientoProducto", cn);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@ID_Producto", idProducto);
                cmd.Parameters.AddWithValue("@ID_Usuario", idUsuario);
                cmd.Parameters.AddWithValue("@Cantidad", cantidad);
                cmd.Parameters.AddWithValue("@Fecha", fecha);
                cmd.Parameters.AddWithValue("@Tipo", tipo);

               // cn.Open();
                var result= cmd.ExecuteNonQuery();
                cn.Close();
            }
        }

    }
}
