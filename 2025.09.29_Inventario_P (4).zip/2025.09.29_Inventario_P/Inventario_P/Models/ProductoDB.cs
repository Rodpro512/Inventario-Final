﻿using Microsoft.Data.SqlClient;
using System.Linq;

namespace Inventario_P.Models
{
    public class ProductoDB
    {

        // Context genérico con constructor vacío o por defecto
        Inventario_P.Context.Context con = new Inventario_P.Context.Context();


        public List<Producto> ObtenerProductos()
        {
            List<Producto> usersBaseDeDatos = new List<Producto>();
            string query = "SELECT * FROM Producto";

            // Abrimos la conexión usando la clase Context
            using (SqlConnection connection = con.OpenConnection())
            using (SqlCommand command = new SqlCommand(query, connection))
            using (SqlDataReader reader = command.ExecuteReader())
            {
                while (reader.Read())
                {
                    int ID_Producto = reader.GetInt32(0);
                    string Nombre = reader.GetString(1);
                    int Codigo = reader.GetInt32(2);
                    int ID_marca = reader.GetInt32(3);
                    int ID_categoria = reader.GetInt32(4);
                    int Cantidad = reader.GetInt32(5);
                    string Descripcion = reader.GetString(6);
                    DateTime fechaDesdeDb = reader.GetDateTime(7);

                    // Agregamos cada fila a la lista
                    usersBaseDeDatos.Add(new Producto
                    {
                        IdProducto = ID_Producto,
                        Nombre = Nombre,
                        Codigo = Codigo,
                        IdMarca = ID_marca,
                        IdCategoria = ID_categoria,
                        Cantidad = Cantidad,
                        Descripcion = Descripcion,
                        Fecha = fechaDesdeDb
                    });
                }
            }

            return usersBaseDeDatos;
        }

        public void ProductoAdd(Producto producto)
        {
            string query = "INSERT INTO Producto(Nombre, Codigo, ID_marca, ID_categoria, Cantidad, Descripcion, Fecha) VALUES (@Nombre, @Codigo, @ID_marca, @ID_categoria, @Cantidad, @Descripcion, @Fecha)";
            using (SqlConnection connection = con.OpenConnection())
            using (SqlCommand command = new SqlCommand(query, connection))
            {
                command.Parameters.AddWithValue("@Nombre", producto.Nombre);
                command.Parameters.AddWithValue("@Codigo", producto.Codigo);
                command.Parameters.AddWithValue("@ID_marca", producto.IdMarca);
                command.Parameters.AddWithValue("@ID_categoria", producto.IdCategoria);
                command.Parameters.AddWithValue("@Cantidad", producto.Cantidad);
                command.Parameters.AddWithValue("@Descripcion", (object?)producto.Descripcion ?? DBNull.Value); //Esta es una forma de decirle al programa de que este dato es null en forma de SQL.
                command.Parameters.AddWithValue("@Fecha", producto.Fecha);

                command.ExecuteNonQuery();
            }
        }
        public List<Marca> ObtenerMarcas()
        {
            List<Marca> marcas = new List<Marca>();
            string query = "SELECT ID_Marca, Nombre_Marca FROM Marca"; 

            using (SqlConnection connection = con.OpenConnection())
            using (SqlCommand command = new SqlCommand(query, connection))
            using (SqlDataReader reader = command.ExecuteReader())
            {
                while (reader.Read())
                {
                    marcas.Add(new Marca
                    {
                        IdMarca = reader.GetInt32(0),
                        NombreMarca = reader.GetString(1)
                    });
                }
            }

            return marcas;
        }

        public List<Categorium> ObtenerCategorias()
        {
            List<Categorium> categorias = new List<Categorium>();
            string query = "SELECT ID_Categoria, Nombre_Categoria FROM Categoria";

            using (SqlConnection connection = con.OpenConnection())
            using (SqlCommand command = new SqlCommand(query, connection))
            using (SqlDataReader reader = command.ExecuteReader())
            {
                while (reader.Read())
                {
                    categorias.Add(new Categorium
                    {
                        IdCategoria = reader.GetInt32(0),
                        NombreCategoria = reader.GetString(1)
                    });
                }
            }

            return categorias;
        }
    }
}
